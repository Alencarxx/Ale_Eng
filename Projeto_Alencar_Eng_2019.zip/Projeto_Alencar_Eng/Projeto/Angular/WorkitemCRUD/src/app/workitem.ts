export class Workitem {
    ID: string;
    Tipo: string;
    Titulo: string;
    DataCriacao: Date;
}
